#!/usr/bin/env node
/**
 * visual-verify.js — HyperFrames 项目视觉自检工具
 *
 * 在 lint 之后、preview 之前执行：把 compositions/ 下每个子组合挂载到
 * 1920×1080 舞台，将 GSAP 时间线 seek 到代表帧，无头浏览器逐镜截图，
 * 并做 DOM 级诊断（GSAP 是否加载、时间线是否注册、元素是否溢出画布）。
 *
 * 用法（项目根目录）：
 *   npm i playwright-core          # 一次性
 *   node tools/visual-verify.js [--seek=2.0] [--browser=<chrome路径>]
 *
 * 可选：在项目根放 verify-seeks.json 指定每镜 seek 秒数，如
 *   { "scene-2-climax.html": 1.6, "scene-1-hook.html": 4.6 }
 *
 * 输出：verify-shots/<场景名>.png + 终端诊断报告。
 */
const fs = require("fs");
const path = require("path");
const os = require("os");

const args = process.argv.slice(2);
const optSeek = Number((args.find(a => a.startsWith("--seek=")) || "").split("=")[1]) || 2.0;
const optBrowser = (args.find(a => a.startsWith("--browser=")) || "").split("=")[1] || "";

const ROOT = process.cwd();
const COMP_DIR = path.join(ROOT, "compositions");
const OUT_DIR = path.join(ROOT, "verify-shots");
const TMP_DIR = path.join(ROOT, ".verify-tmp");

function findBrowser() {
  if (optBrowser && fs.existsSync(optBrowser)) return optBrowser;
  const base = path.join(os.homedir(), "AppData", "Local", "ms-playwright");
  const cands = [];
  if (fs.existsSync(base)) {
    for (const d of fs.readdirSync(base)) {
      cands.push(path.join(base, d, "chrome-headless-shell-win64", "chrome-headless-shell.exe"));
      cands.push(path.join(base, d, "chrome-win", "chrome.exe"));
    }
  }
  cands.push(
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files/Google/Chrome/Application/chrome.exe"
  );
  return cands.find(p => fs.existsSync(p)) || "";
}

function extractTemplate(file) {
  const src = fs.readFileSync(file, "utf8");
  const m = src.match(/<template>([\s\S]*)<\/template>/);
  return m ? m[1] : null;
}

function buildHarness(name, inner, seek) {
  // harness 放在 .verify-tmp/ 内，gsap 相对路径指回项目 assets/
  const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<script src="../assets/gsap.min.js"></script>
<script>window.__timelines = {};</script>
<style>html,body{margin:0;width:1920px;height:1080px;overflow:hidden;background:#070a12;}
#stage{position:relative;width:1920px;height:1080px;overflow:hidden;}</style>
</head>
<body>
<div id="stage">
${inner}
</div>
<script>
  window.addEventListener('load', function () {
    setTimeout(function () {
      Object.keys(window.__timelines || {}).forEach(function (k) {
        var tl = window.__timelines[k];
        tl.pause(0); tl.seek(${seek});
      });
    }, 300);
  });
</script>
</body>
</html>`;
  const fp = path.join(TMP_DIR, name.replace(/\.html$/, "") + ".verify.html");
  fs.writeFileSync(fp, html, "utf8");
  return fp;
}

(async () => {
  if (!fs.existsSync(COMP_DIR)) {
    console.error("[visual-verify] 未找到 compositions/ 目录，请在 HyperFrames 项目根目录执行。");
    process.exit(1);
  }
  let chromium;
  try {
    chromium = require("playwright-core").chromium;
  } catch (e) {
    console.error("[visual-verify] 缺少依赖，请先执行：npm i playwright-core");
    process.exit(1);
  }
  const browserPath = findBrowser();
  if (!browserPath) {
    console.error("[visual-verify] 未找到无头浏览器，请执行 npx playwright install chromium 或用 --browser= 指定 Chrome/Edge 路径。");
    process.exit(1);
  }

  // 每镜 seek 秒数：verify-seeks.json > --seek 参数 > 默认 2.0
  let seekMap = {};
  const seekFile = path.join(ROOT, "verify-seeks.json");
  if (fs.existsSync(seekFile)) seekMap = JSON.parse(fs.readFileSync(seekFile, "utf8"));

  fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.mkdirSync(TMP_DIR, { recursive: true });

  const files = fs.readdirSync(COMP_DIR).filter(f => f.endsWith(".html")).sort();
  if (!files.length) {
    console.error("[visual-verify] compositions/ 下没有子组合文件。");
    process.exit(1);
  }

  const browser = await chromium.launch({ executablePath: browserPath });
  const report = [];

  for (const f of files) {
    const inner = extractTemplate(path.join(COMP_DIR, f));
    if (!inner) { report.push({ file: f, ok: false, issues: ["未找到 <template> 块"] }); continue; }
    const seek = seekMap[f] !== undefined ? seekMap[f] : optSeek;
    const harness = buildHarness(f, inner, seek);

    const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
    const pageErrors = [];
    page.on("pageerror", e => pageErrors.push(e.message));
    await page.goto("file:///" + harness.replace(/\\/g, "/"));
    await page.waitForTimeout(2500);

    const diag = await page.evaluate(() => {
      const issues = [];
      if (typeof window.gsap === "undefined") issues.push("GSAP 未加载（检查 assets/gsap.min.js 是否存在）");
      const keys = Object.keys(window.__timelines || {});
      if (!keys.length) issues.push("window.__timelines 为空（时间线未注册）");
      // 画布溢出检查：任何可见元素超出 1920×1080 安全区
      const overflow = [];
      document.querySelectorAll("#stage *").forEach(el => {
        const r = el.getBoundingClientRect();
        const st = getComputedStyle(el);
        if (st.display === "none" || Number(st.opacity) === 0) return;
        if (r.width === 0 || r.height === 0) return;
        if (r.left < -1 || r.top < -1 || r.right > 1921 || r.bottom > 1081) {
          if (!el.hasAttribute("data-layout-allow-overflow")) {
            overflow.push((el.id ? "#" + el.id : el.className) + ` [${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.right)},${Math.round(r.bottom)}]`);
          }
        }
      });
      if (overflow.length) issues.push("元素溢出画布: " + overflow.slice(0, 5).join(" | "));
      return { issues, timelineKeys: keys };
    });

    const out = path.join(OUT_DIR, f.replace(/\.html$/, "") + ".png");
    await page.screenshot({ path: out });
    await page.close();

    const issues = [...pageErrors.map(e => "JS 错误: " + e), ...diag.issues];
    report.push({ file: f, ok: issues.length === 0, issues, seek, timelines: diag.timelineKeys, shot: path.relative(ROOT, out) });
  }

  await browser.close();
  fs.rmSync(TMP_DIR, { recursive: true, force: true });

  console.log("\n===== 视觉自检报告 =====");
  for (const r of report) {
    if (r.ok) {
      console.log(`PASS  ${r.file}  (seek=${r.seek}s, timelines=[${r.timelines.join(",")}]) -> ${r.shot}`);
    } else {
      console.log(`FAIL  ${r.file}`);
      r.issues.forEach(i => console.log(`      - ${i}`));
    }
  }
  const fails = report.filter(r => !r.ok).length;
  console.log(`\n共 ${report.length} 镜，通过 ${report.length - fails}，失败 ${fails}。截图见 verify-shots/，请逐张人工过目。`);
  process.exit(fails ? 2 : 0);
})();
